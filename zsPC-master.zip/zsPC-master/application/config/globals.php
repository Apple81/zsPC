<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
                 
$config['globals_text'] = "test text";

//Java数据接口
//$config['URL_API'] = "http://112.74.34.150:8080/";
                 
